# UNLOCK — AI Case Room

Website prototipe board game UNLOCK dengan Netlify Function yang menghubungkan form ke OpenAI Responses API.

## Isi folder
- `index.html` — tampilan website dan form pemain.
- `netlify/functions/analyze.mjs` — backend AI; API key hanya dibaca di server.
- `netlify.toml` — konfigurasi folder Netlify Functions.

## Deploy (penting)
Netlify Drop untuk file statis saja tidak cukup untuk menjalankan function ini. Deploy proyek melalui repository Git yang dihubungkan ke Netlify, atau Netlify CLI. Cara termudah untuk proyek ini adalah GitHub + Netlify:
1. Buat repository baru di GitHub.
2. Unggah semua isi folder proyek ini dengan struktur folder tetap sama.
3. Di Netlify, pilih Add new project / Import an existing project, lalu hubungkan repository tersebut.
4. Build command boleh dikosongkan; publish directory isi `.`. Folder function sudah ditentukan di `netlify.toml`.
5. Setelah deploy, buka Project configuration → Environment variables.
6. Tambahkan `OPENAI_API_KEY` dengan API key milik pemilik akun dewasa/wali yang mengelola proyek. Batasi scope ke Functions jika pilihan scope tersedia.
7. Opsional: tambahkan `OPENAI_MODEL` dengan model API yang tersedia pada akun. Default proyek ini `gpt-6.2-astra`.
8. Simpan lalu lakukan redeploy agar variabel baru aktif.

## Keamanan
- JANGAN menaruh API key di `index.html`, GitHub, chat, atau QR code.
- Jangan meminta pemain mengisi nama lengkap, nomor telepon, data sekolah, atau cerita pribadi. Gunakan kasus fiktif.
- API dapat menimbulkan biaya sesuai penggunaan dan pengaturan akun. Minta orang tua/wali atau guru mendampingi pengaturan akun, API key, dan batas penggunaan.
- AI memberi umpan balik edukatif, bukan diagnosis atau pengganti bantuan guru BK/profesional.
- Jika key pernah terlanjur terunggah ke tempat publik, cabut/revoke key tersebut dan buat yang baru.

## Endpoint
POST `/.netlify/functions/analyze`
JSON body: `{ "caseId": "raka-001", "team": "Kelompok 1", "answer": "...", "reason": "...", "action": "..." }`
