export default async (req) => {
  if (req.method !== "POST") {
    return Response.json({ error: "Metode tidak didukung." }, { status: 405 });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return Response.json({ error: "OPENAI_API_KEY belum dipasang di Netlify Environment variables." }, { status: 503 });
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Format permintaan tidak valid." }, { status: 400 });
  }

  const allowedCase = body.caseId === "raka-001";
  const answer = String(body.answer || "").slice(0, 250);
  const reason = String(body.reason || "").trim().slice(0, 1200);
  const action = String(body.action || "").trim().slice(0, 600);
  const team = String(body.team || "").slice(0, 40);

  if (!allowedCase || !answer || !reason) {
    return Response.json({ error: "Data kasus, jawaban, atau alasan belum lengkap." }, { status: 400 });
  }

  const caseFacts = `
Kasus fiktif Raka:
- Raka biasanya aktif, tetapi beberapa minggu terakhir lebih diam dan sulit fokus.
- Nilai ulangan matematika menurun.
- Ada tugas yang belum selesai.
- Bella melihat Raka lebih sering menyendiri saat istirahat.
- Raka pernah mengatakan khawatir tentang nilai.
- Bella: Raka lebih sering belajar sendiri.
- Dimas: Raka pernah mengatakan kesulitan memahami matematika.
- Bu Anita: Raka biasanya aktif bertanya, tetapi belakangan jarang bertanya.
- Keluarga: jadwal belajar Raka di rumah cukup padat.

Jawaban kelompok: ${answer}
Alasan kelompok: ${reason}
Usulan tindakan kelompok: ${action || "(belum diisi)"}
Nama kelompok: ${team || "(tidak diisi)"}
`;

  const instructions = `Kamu adalah fasilitator edukasi untuk permainan UNLOCK, bukan tenaga kesehatan dan bukan alat diagnosis. Analisis hanya kasus fiktif di bawah. Jawab dalam Bahasa Indonesia yang ramah, jelas, dan cocok untuk siswa SMA kelas 10.

Aturan:
- Jangan mendiagnosis, memberi label gangguan mental, atau menyatakan pasti apa yang dirasakan tokoh.
- Jangan menyimpulkan satu penyebab pasti jika bukti belum cukup. Tekankan beberapa kemungkinan dapat saling berkaitan.
- Evaluasi kualitas alasan, bukan hanya cocok/tidak cocoknya opsi.
- Hubungkan secara spesifik petunjuk yang mendukung dan petunjuk yang masih kurang.
- Jika jawaban kelompok terlalu yakin, ingatkan bahwa informasi masih terbatas.
- Berikan 1 pertanyaan refleksi dan 2-3 tindakan suportif yang realistis.
- Jika usulan tindakan menyalahkan, mempermalukan, memaksa, atau menghakimi tokoh, jelaskan dengan lembut dan sarankan alternatif.
- Jangan meminta atau mengulang data pribadi orang sungguhan.
- Batasi jawaban sekitar 180-250 kata dengan judul kecil: "Umpan Balik AI", "Petunjuk yang Relevan", "Hal yang Belum Diketahui", "Langkah Suportif", dan "Pertanyaan Refleksi".
- Ingatkan bahwa teman dapat mendengarkan dan mengajak tokoh berbicara dengan guru BK, wali kelas, atau orang dewasa tepercaya bila perlu.`;

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-6.2-astra",
        instructions,
        input: caseFacts,
        max_output_tokens: 500
      })
    });

    const result = await response.json();
    if (!response.ok) {
      return Response.json({ error: "Layanan AI menolak permintaan. Periksa pengaturan API dan batas penggunaan." }, { status: 502 });
    }

    const text = (result.output || [])
      .flatMap(item => item.content || [])
      .filter(item => item.type === "output_text")
      .map(item => item.text)
      .join("\n")
      .trim();

    if (!text) {
      return Response.json({ error: "AI belum menghasilkan jawaban. Coba lagi." }, { status: 502 });
    }

    return Response.json({ analysis: text });
  } catch {
    return Response.json({ error: "Server tidak dapat menghubungi layanan AI saat ini." }, { status: 502 });
  }
};
